#!/bin/bash

zip -T output.zip
unzip -t output.zip
unzip -l output.zip
