#!/bin/bash

echo "Here I am!"
echo "Yay, it works!"
